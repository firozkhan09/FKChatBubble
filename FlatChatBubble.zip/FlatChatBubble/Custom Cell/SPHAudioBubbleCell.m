//
//  SPHAudioBubbleCell.m
//  tawk@Eaze
//
//  Created by Santosh Narawade on 26/12/15.
//  Copyright (c) 2015 Santosh Narawade. All rights reserved.
//

#import "SPHAudioBubbleCell.h"
#import "Constantvalues.h"

@implementation SPHAudioBubbleCell

@synthesize timestampLabel = _timestampLabel;
@synthesize AvatarImageView = _AvatarImageView;
@synthesize musicSlider = _musicSlider;
@synthesize actionButton = _actionButton;

/*
*****************================================================************************
*****************************| INITIALIZE OF  CELL |*************************************
*****************================================================************************
 */

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
  self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
  if (self) {
    self.backgroundColor = [UIColor clearColor];
    if ([[UIDevice currentDevice].systemVersion floatValue] < 7.0f) {
      self.textLabel.backgroundColor = [UIColor whiteColor];
    }
    self.textLabel.font = [UIFont systemFontOfSize:14.0f];
    self.textLabel.lineBreakMode = NSLineBreakByWordWrapping;
    self.textLabel.numberOfLines = 0;
    self.textLabel.textAlignment = NSTextAlignmentLeft;
    self.textLabel.textColor = [UIColor clearColor];
    
    messageBackgroundView = [[UIImageView alloc] initWithFrame:self.textLabel.frame];
    messageBackgroundView.layer.cornerRadius = 15.0f;
    messageBackgroundView.layer.shadowOffset = CGSizeMake(2, 0);
    messageBackgroundView.layer.shadowColor = [[UIColor blackColor] CGColor];
    messageBackgroundView.layer.shadowRadius = 5;
    messageBackgroundView.layer.shadowOpacity = .5;
    [self.contentView addSubview:messageBackgroundView];
    
    //Time and Status View
    containerView = [[UIView alloc]initWithFrame:CGRectMake(5, messageBackgroundView.frame.size.height - 23, messageBackgroundView.frame.size.width - 30, 18)];
    containerView.backgroundColor = [UIColor clearColor];
    [messageBackgroundView insertSubview:containerView aboveSubview:self.textLabel];
    
    _timestampLabel = [[UILabel alloc] init];
    _timestampLabel.autoresizingMask = UIViewAutoresizingFlexibleWidth;
    _timestampLabel.textAlignment = NSTextAlignmentRight;
    _timestampLabel.backgroundColor = [UIColor clearColor];
    _timestampLabel.font = [UIFont systemFontOfSize:12.0f];
    _timestampLabel.textColor = [UIColor blackColor];
    [containerView addSubview:_timestampLabel];
    
    _statusImageView = [[UIImageView alloc] init];
    [containerView addSubview:_statusImageView];
    //end
    
    _actionButton   = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    _actionButton.layer.cornerRadius = 15.0f;
    [self.contentView addSubview:_actionButton];
    
    //change
    //indicator create
    _indicator = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
    _indicator.color = [UIColor colorWithRed:42.0f/255.0f green:125.0f/255.0f blue:215.0f/255.0f alpha:1.0f];
    [self.contentView addSubview:_indicator];
    _indicator.hidden = YES;
    //end
#warning progress view
    _musicSlider = [[UISlider alloc] initWithFrame:CGRectMake(0.5, 0.5, 1, 1)];
    [_musicSlider setBackgroundColor:[UIColor clearColor]];
    [_musicSlider setThumbImage: [UIImage imageNamed:@"offline"] forState:UIControlStateNormal];
    
    _musicSlider.minimumValue = 0.0;
    _musicSlider.maximumValue = 1.0;
    _musicSlider.continuous = YES;
    _musicSlider.value = 0.0;
    [messageBackgroundView addSubview:_musicSlider];
    
    self.AvatarImageView = [[UIImageView alloc] initWithFrame:CGRectMake(5,10+TOP_MARGIN, 50, 50)];
    self.AvatarImageView.contentMode = UIViewContentModeScaleAspectFill; 
    [self.contentView addSubview:self.AvatarImageView];
    CALayer * l = [self.AvatarImageView layer];
    [l setMasksToBounds:YES];
    [l setCornerRadius:self.AvatarImageView.frame.size.width/2.0];
    
    UITapGestureRecognizer *ttp = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapToPopupRecognized:)];
    [ttp setNumberOfTapsRequired:1];
    ttp.delegate = self;
    [_AvatarImageView addGestureRecognizer:ttp];
    
    UITapGestureRecognizer *cellTap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(cellTapRecognized:)];
    [cellTap setNumberOfTapsRequired:1];
    cellTap.delegate = self;
    [self addGestureRecognizer:cellTap];
    
    UILongPressGestureRecognizer *lpgr
    = [[UILongPressGestureRecognizer alloc]
       initWithTarget:self action:@selector(tapRecognized:)];
    lpgr.minimumPressDuration = .4; //seconds
    lpgr.delegate = self;
    [self addGestureRecognizer:lpgr];
    
    UISwipeGestureRecognizer *sgr
    = [[UISwipeGestureRecognizer alloc]
       initWithTarget:self action:@selector(swipRecognized:)];
    sgr.direction = UISwipeGestureRecognizerDirectionLeft;
    sgr.delegate = self;
    [messageBackgroundView addGestureRecognizer:sgr];
  }
  return self;
}

/*
**********************=============================================**********************
*****************************|_DELEGATE_FUNCTIONS_OF_CELL_|******************************
**********************=============================================**********************
 */

-(void)actionButtonTapped:(UIButton *)sender{
  if (![[NSUserDefaults standardUserDefaults] boolForKey:@"AudioUnderProgress"]) {
    (_isDownloaded)?[self.CustomDelegate playAudio:sender]:
    (_isRecived)?   [self.CustomDelegate downloadAudio:sender]:
    [self.CustomDelegate uploadAudio:sender];
  }
}

-(void)tapRecognized:(UITapGestureRecognizer *)tapGR
{
  if (_isDownloaded)
    [self.CustomDelegate audioCellDidTapped:self AndGesture:tapGR];
}

-(void)swipRecognized:(UITapGestureRecognizer *)swipGR
{
  if (_isDownloaded && _isGroup)
    [self.CustomDelegate audioCellDidPanned:self AndGesture:swipGR];
}

-(void)tapToPopupRecognized:(UITapGestureRecognizer *)tapGR
{
  [self.CustomDelegate popupAvatarImageView:self];
}

-(void)cellTapRecognized:(UITapGestureRecognizer *)tapGR
{
  [self.CustomDelegate audioCellDidSelected:self AndGesture:tapGR];
}

- (BOOL)canBecomeFirstResponder {
  return YES;
}

- (BOOL)canPerformAction:(SEL)action withSender:(id)sender
{
  if (action==@selector(forward:) || action==@selector(delete:) || action==@selector(info:)) {
    return YES;
  }
  return NO;
}

- (IBAction)forward:(id)sender
{
  [self.CustomDelegate cellForwardPressed];
  self.selectionStyle = UITableViewCellSelectionStyleDefault;
  [self.CustomDelegate audioCellDidSelected:self AndGesture:nil];
}

- (IBAction)info:(id)sender
{
  [self.CustomDelegate audioCellDidPanned:self AndGesture:nil];
}

- (IBAction)delete:(id)sender
{
  [self.CustomDelegate cellDeletePressed];
  self.selectionStyle = UITableViewCellSelectionStyleDefault;
  [self.CustomDelegate audioCellDidSelected:self AndGesture:nil];
}

- (void)showMenu
{
  [[UIMenuController sharedMenuController] setMenuVisible:NO animated:YES];
  [self becomeFirstResponder];
  UIMenuItem *menuItem = [[UIMenuItem alloc] initWithTitle:@"Share" action:@selector(forward:)];
  UIMenuItem *menuItemInfo = [[UIMenuItem alloc] initWithTitle:@"Info" action:@selector(info:)];
  [[UIMenuController sharedMenuController] setMenuItems:[NSArray arrayWithObjects:menuItem,(_isGroup && !_isRecived)?menuItemInfo:nil,nil]];
  [[UIMenuController sharedMenuController] update];
  
  CGRect textFrame=messageBackgroundView.frame;
  textFrame.origin.x=messageBackgroundView.center.x;
  textFrame.origin.y=messageBackgroundView.center.y;
  
  [[UIMenuController sharedMenuController] setTargetRect:textFrame inView:self];
  [[UIMenuController sharedMenuController] setMenuVisible:YES animated:YES];
  
}

/*
**********************=============================================**********************
*************************************| LAYOUT OF  CELL |*********************************
**********************=============================================**********************
 */

- (void)layoutSubviews
{
  [super layoutSubviews];
  
  if (_isRecived)
  {
    messageBackgroundView.frame = CGRectMake(60, TOP_MARGIN-12, self.contentView.frame.size.width-110, 60);
    self.AvatarImageView.frame=CGRectMake(5, 0, 50, 50);
    [_AvatarImageView setUserInteractionEnabled:YES];
    [messageBackgroundView setUserInteractionEnabled:NO];
    containerView.frame = CGRectMake(5, messageBackgroundView.frame.size.height - 28, messageBackgroundView.frame.size.width - 15, 25);
    _timestampLabel.frame = CGRectMake(-30, 5, containerView.frame.size.width-3, 18);
    _timestampLabel.textAlignment = NSTextAlignmentCenter;
    _statusImageView.image = nil;
    _statusImageView.backgroundColor = [UIColor clearColor];
    containerView.hidden = NO;
    _actionButton.frame = CGRectMake( 68, 23, 30, 30);
    [_actionButton setBackgroundImage:(_isDownloaded)?[UIImage imageNamed:@"play"]:[UIImage imageNamed:@"download"]  forState:UIControlStateNormal];
    _musicSlider.frame = CGRectMake(40, 12, messageBackgroundView.frame.size.width-53, 40);
    
  }else
  {
    messageBackgroundView.frame = CGRectMake( 50,TOP_MARGIN-12,self.contentView.frame.size.width-110, 60);
    self.AvatarImageView.frame=CGRectMake( self.frame.size.width-55, 0, 50, 50);
    [_AvatarImageView setUserInteractionEnabled:NO];
    [messageBackgroundView setUserInteractionEnabled:YES];
    _actionButton.frame = CGRectMake( messageBackgroundView.frame.size.width + 10, 23, 30, 30);
    containerView.frame = CGRectMake(10, messageBackgroundView.frame.size.height - 28, messageBackgroundView.frame.size.width - 15, 25);
    _timestampLabel.frame = CGRectMake(-30, 7, containerView.frame.size.width-80, 18);
    _statusImageView.frame = CGRectMake(_timestampLabel.frame.size.width-28.5, 7, 36, 18);
    UIColor *SIVbackgroundColor = (_isGroup)? 
    [UIColor clearColor]:
    [UIColor colorWithRed:0.0f/255.0f green:0.0f/255.0f blue:0.0f/255.0f alpha:0.15f];
    _statusImageView.backgroundColor = SIVbackgroundColor;
    _statusImageView.layer.cornerRadius = 5.0f;
    _statusImageView.image = (_isGroup)?nil:_statusImage;
    containerView.hidden = (_isDownloaded)?NO:YES;
    
    [_actionButton setBackgroundImage:(_isDownloaded)?[UIImage imageNamed:@"play"]:[UIImage imageNamed:@"upload"] forState:UIControlStateNormal];
    _musicSlider.frame = CGRectMake(8, 6.5, messageBackgroundView.frame.size.width-53, 50);
    
    //change layout on editing
    if (self.selectionStyle != UITableViewCellSelectionStyleNone) {
      CGRect avtarframe = self.AvatarImageView.frame;
      avtarframe.origin.x = avtarframe.origin.x-35;
      self.AvatarImageView.frame = avtarframe;
    }
    //end
  }
  
  _indicator.hidden = (_isProgressing)?NO:YES;
  _indicator.center = self.actionButton.center;
  (_isProgressing)?[_indicator startAnimating]:[_indicator stopAnimating];
  _actionButton.hidden = _isProgressing;
  [_actionButton addTarget:self action:@selector(actionButtonTapped:) forControlEvents:UIControlEventTouchUpInside];
  messageBackgroundView.backgroundColor = [UIColor whiteColor];
  messageBackgroundView.layer.cornerRadius = 8.0f;
}

@end
