//
//  SPHMediaBubbleCell.h
//  NewChatBubble
//
//  Created by Siba Prasad Hota  on 1/3/15.
//  Copyright (c) 2015 Wemakeappz. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol MediaCellDelegate;

@interface SPHMediaBubbleCell : UITableViewCell
{
    UIImageView *messageBackgroundView;
    UIView *containerView;
}
@property (nonatomic,retain) UILabel                  *timestampLabel;
@property (nonatomic,strong) NSString                 *dataType;
@property (nonatomic,strong) UIImageView              *AvatarImageView;
@property (nonatomic,strong) UIImageView              *messageImageView;
@property (nonatomic,retain) UIImageView              *statusImageView;
@property (nonatomic,retain) UIImage                  *statusImage;
@property (nonatomic,strong) UIButton                 *downloadImageButton;
@property (nonatomic,strong) UIProgressView           *downloadProgressView;
@property (nonatomic,strong) UIActivityIndicatorView  *indicator;//change

@property (nonatomic) BOOL isDownloaded, isRecived, isGroup, isProgressing;

@property (nonatomic, assign) id <MediaCellDelegate> CustomDelegate;

- (void)showMenu;

@end


@protocol MediaCellDelegate
@required

-(void)downloadMedia:(UIButton *)sender;
-(void)uploadMedia:(UIButton *)sender;
-(void)playVideo:(UIButton *)sender;

-(void)mediaCellDidTapped:(SPHMediaBubbleCell *)mediaCell AndGesture:(UIGestureRecognizer*)tapGR;
-(void)mediaCellDidPanned:(SPHMediaBubbleCell *)mediaCell AndGesture:(UIGestureRecognizer*)panGR;

-(void)cellForwardPressed;
-(void)cellDeletePressed;

-(void)imageDidSelected:(SPHMediaBubbleCell *)mediaCell AndGesture:(UIGestureRecognizer*)tapGR;
-(void)popupAvatarImageView:(SPHMediaBubbleCell *)mediaCell;

@end