//
//  SPHLeftBubbleCell.m
//  NewChatBubble
//
//  Created by Siba Prasad Hota  on 1/3/15.
//  Copyright (c) 2015 Wemakeappz. All rights reserved.
//

#import "SPHTextBubbleCell.h"
#import "UIImage+Utils.h"
#import "Constantvalues.h"

#import <CoreGraphics/CoreGraphics.h>
#import <UIKit/UIKit.h>

@implementation SPHTextBubbleCell

@synthesize timestampLabel = _timestampLabel;


/*
******************================================================***********************
*********************************| INITIALIZE OF  CELL |*********************************
******************================================================***********************
*/

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
  self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
  if (self) {
    self.backgroundColor = [UIColor clearColor];
    if ([[UIDevice currentDevice].systemVersion floatValue] < 7.0f) {
      self.textLabel.backgroundColor = [UIColor whiteColor];
    }
    self.textLabel.font = [UIFont systemFontOfSize:14.0f];
    self.textLabel.lineBreakMode = NSLineBreakByWordWrapping;
    self.textLabel.numberOfLines = 0;
    self.textLabel.textAlignment = NSTextAlignmentLeft;
    
    self.textView = [[UITextView alloc] init];
    self.textView.font = [UIFont systemFontOfSize:14.0f];
    self.textView.textAlignment = NSTextAlignmentLeft;
    self.textView.backgroundColor = [UIColor clearColor];
    self.textView.scrollEnabled = NO;
    self.textView.editable = NO;
    self.textView.dataDetectorTypes=UIDataDetectorTypeLink|UIDataDetectorTypePhoneNumber;
    self.textView.delegate = self;
    [self.contentView insertSubview:self.textView aboveSubview:self.textLabel];
    
    messageBackgroundView = [[UIImageView alloc] initWithFrame:self.textLabel.frame];
    [self.contentView insertSubview:messageBackgroundView belowSubview:self.textLabel];
    
    //Time and Status View
    containerView = [[UIView alloc]initWithFrame:CGRectMake(5, messageBackgroundView.frame.size.height - 23, messageBackgroundView.frame.size.width - 30, 18)];
    containerView.backgroundColor = [UIColor clearColor];
    [messageBackgroundView insertSubview:containerView aboveSubview:self.textLabel];
    
    _timestampLabel = [[UILabel alloc] init];
    _timestampLabel.autoresizingMask = UIViewAutoresizingFlexibleWidth;
    _timestampLabel.textAlignment = NSTextAlignmentRight;
    _timestampLabel.backgroundColor = [UIColor clearColor];
    _timestampLabel.font = [UIFont systemFontOfSize:12.0f];
    _timestampLabel.textColor = [UIColor blackColor];
    [containerView addSubview:_timestampLabel];
    
    _statusImageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"seen_status"]];
    [containerView addSubview:_statusImageView];
    //end
    
    self.AvatarImageView = [[UIImageView alloc] initWithFrame:CGRectMake(5,10+TOP_MARGIN, 50, 50)];
    self.AvatarImageView.contentMode = UIViewContentModeScaleAspectFill;    
    [self.contentView addSubview:self.AvatarImageView];
    
    CALayer * l = [self.AvatarImageView layer];
    [l setMasksToBounds:YES];
    [l setCornerRadius:self.AvatarImageView.frame.size.width/2.0];
    
    UITapGestureRecognizer *ttp = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapToPopupRecognized:)];
    [ttp setNumberOfTapsRequired:1];
    ttp.delegate = self;
    [_AvatarImageView addGestureRecognizer:ttp];
    
    UITapGestureRecognizer *cellTap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(cellTapRecognized:)];
    [cellTap setNumberOfTapsRequired:1];
    cellTap.delegate = self;
    [self addGestureRecognizer:cellTap];

    UILongPressGestureRecognizer *lpgr
    = [[UILongPressGestureRecognizer alloc]
       initWithTarget:self action:@selector(tapRecognized:)];
    lpgr.minimumPressDuration = .4; //seconds
    lpgr.delegate = self;
    [self addGestureRecognizer:lpgr];
    
    //        UIPanGestureRecognizer *pgr
    //        = [[UIPanGestureRecognizer alloc]
    //           initWithTarget:self action:@selector(panRecognized:)];
    //        pgr.delegate = self;
    //        [messageBackgroundView addGestureRecognizer:pgr];
    UISwipeGestureRecognizer *sgr
    = [[UISwipeGestureRecognizer alloc]
       initWithTarget:self action:@selector(swipRecognized:)];
    sgr.direction = UISwipeGestureRecognizerDirectionLeft;
    sgr.delegate = self;
    [_textView addGestureRecognizer:sgr];
  }
  
  return self;
}

/*
***********************=============================================*********************
******************************|_DELEGATE_FUNCTIONS_OF_CELL_|*****************************
***********************=============================================*********************
*/

- (BOOL)textView:(UITextView *)textView shouldInteractWithURL:(NSURL *)URL inRange:(NSRange)characterRange NS_AVAILABLE_IOS(7_0)
{
  return YES;
}

-(void)tapRecognized:(UITapGestureRecognizer *)tapGR
{
  [self.CustomDelegate textCellDidTapped:self AndGesture:tapGR];
}

-(void)panRecognized:(UITapGestureRecognizer *)panGR
{
  //    if (!_isSecondCall) {
  //        [self.CustomDelegate containerViewDidPanned:self AndGesture:panGR];
  //        _isSecondCall = YES;
  //        return;
  //    }
  //    _isSecondCall = NO;
}

-(void)swipRecognized:(UITapGestureRecognizer *)swipGR
{
  if(_isGroup)[self.CustomDelegate textCellDidPanned:self AndGesture:swipGR];
}

-(void)tapToPopupRecognized:(UITapGestureRecognizer *)tapGR
{
  [self.CustomDelegate popupAvatarImageView:self];
}

-(void)cellTapRecognized:(UITapGestureRecognizer *)tapGR
{
  [self.CustomDelegate textCellDidSelected:self AndGesture:tapGR];
}

- (BOOL)canBecomeFirstResponder {
  return YES;
}
- (BOOL)canPerformAction:(SEL)action withSender:(id)sender
{
  if (action == @selector(copy:)|| action==@selector(forward:) || action==@selector(delete:) || action==@selector(info:)) {
    return YES;
  }
  return NO;
}

- (IBAction)copy:(id)sender
{
  [self.CustomDelegate cellCopyPressed:self];
}

- (IBAction)delete:(id)sender
{
  [self.CustomDelegate cellDeletePressed];
  self.selectionStyle = UITableViewCellSelectionStyleDefault;
  [self.CustomDelegate textCellDidSelected:self AndGesture:nil];
}

- (IBAction)forward:(id)sender
{
  [self.CustomDelegate cellForwardPressed];
  self.selectionStyle = UITableViewCellSelectionStyleDefault;
  [self.CustomDelegate textCellDidSelected:self AndGesture:nil];
}

- (IBAction)info:(id)sender
{
  [self.CustomDelegate textCellDidPanned:self AndGesture:nil];
}

- (void)showMenu
{
  [[UIMenuController sharedMenuController] setMenuVisible:NO animated:YES];
  [self becomeFirstResponder];
  UIMenuItem *menuItem = [[UIMenuItem alloc] initWithTitle:@"Forward" action:@selector(forward:)];
  UIMenuItem *menuItemInfo = [[UIMenuItem alloc] initWithTitle:@"Info" action:@selector(info:)];
  
  [[UIMenuController sharedMenuController] setMenuItems:[NSArray arrayWithObjects:menuItem, (_isGroup && ![self.bubbletype isEqualToString:@"LEFT"])?menuItemInfo:nil, nil]];
  [[UIMenuController sharedMenuController] update];
  CGRect textFrame=self.textLabel.frame; textFrame.origin.x-=50;
  [[UIMenuController sharedMenuController] setTargetRect:textFrame inView:self];
  [[UIMenuController sharedMenuController] setMenuVisible:YES animated:YES];
  
}

/*
**********************=============================================**********************
*************************************| LAYOUT OF  CELL |*********************************
**********************=============================================**********************
*/

- (void)layoutSubviews
{
  [super layoutSubviews];
  NSString *messageString = [NSString stringWithFormat:@"%@",self.textView.text];
  CGSize labelSize =[messageString boundingRectWithSize:CGSizeMake(self.frame.size.width-104, MAXFLOAT)
                                                      options:NSStringDrawingUsesLineFragmentOrigin
                                                   attributes:@{ NSFontAttributeName:[UIFont systemFontOfSize:14.0f] }
                                                      context:nil].size;
  labelSize.width= (labelSize.width<150)?150:labelSize.width;
  
  if ([self.bubbletype isEqualToString:@"LEFT"])
  {
    CGRect textLabelFrame = self.textLabel.frame;
    textLabelFrame.origin.x = 60;
    textLabelFrame.size.width = self.frame.size.width-94;
    textLabelFrame.size.height = labelSize.height+9;
    textLabelFrame.origin.y = TOP_MARGIN - 12;
    self.textView.frame = textLabelFrame;
    self.textView.textColor = [UIColor whiteColor];
    messageBackgroundView.frame = CGRectMake(53, textLabelFrame.origin.y - 5, labelSize.width + 20,labelSize.height + 32);//18
    self.AvatarImageView.frame=CGRectMake(5, 0, 50, 50);
    [_AvatarImageView setUserInteractionEnabled:YES];
    [messageBackgroundView setUserInteractionEnabled:NO];
    
    containerView.frame = CGRectMake(5, messageBackgroundView.frame.size.height - 28, messageBackgroundView.frame.size.width - 15, 25);
    _timestampLabel.frame = CGRectMake(-30, 5, containerView.frame.size.width, 18);
    _statusImageView.image = nil;
    
    UIImage *coloredImage = [[UIImage imageNamed:@"masg_left_bubble"] maskWithColor:BLUE_TEXT_HIGHLIGHT_COLOR];
    messageBackgroundView.image = [[UIImage imageWithCGImage:coloredImage.CGImage] stretchableImageWithLeftCapWidth:20 topCapHeight:16];
    
  }else  // Right
  {
    
    CGRect textLabelFrame = self.textLabel.frame;
    textLabelFrame.size.width = self.frame.size.width-94;
    self.textView.frame = textLabelFrame;
    
    textLabelFrame.size.height = labelSize.height + 11;
    textLabelFrame.origin.y = TOP_MARGIN - 12;
    textLabelFrame.origin.x = self.bounds.size.width - labelSize.width -70;
    self.textView.frame = textLabelFrame;
    self.textView.textColor = [UIColor colorWithRed:36.0f/255.0f green:123.0f/255.0f blue:186.0f/255.0f alpha:1.0f];
    messageBackgroundView.frame = CGRectMake(textLabelFrame.origin.x - 2, textLabelFrame.origin.y - 2, labelSize.width + 20, labelSize.height + 28);//18
    
    containerView.frame = CGRectMake(10, messageBackgroundView.frame.size.height - 28, messageBackgroundView.frame.size.width - 15, 25);
    int w = (_isGroup)?10:42;
    _timestampLabel.frame = CGRectMake(-30, 5, containerView.frame.size.width-w, 18);
    _statusImageView.frame = CGRectMake(_timestampLabel.frame.size.width-26.5, 5, 36, 18);
    _statusImageView.image = (_isGroup)?nil:_statusImage;
    self.AvatarImageView.frame=CGRectMake( self.frame.size.width-55, 0, 50, 50);
    [_AvatarImageView setUserInteractionEnabled:NO];
    [messageBackgroundView setUserInteractionEnabled:YES];
    
    UIImage *coloredImage = [[UIImage imageNamed:@"masg_right_bubble"] maskWithColor:GRAY_TEXT_BUBBLE_COLOR];
    messageBackgroundView.image = [[UIImage imageWithCGImage:coloredImage.CGImage] stretchableImageWithLeftCapWidth:20 topCapHeight:16];
    
    //change layout on editing
    if (self.selectionStyle != UITableViewCellSelectionStyleNone) {
      CGRect tvframe = self.textView.frame;
      CGRect mbframe = messageBackgroundView.frame;
      CGRect avtarframe = self.AvatarImageView.frame;
      tvframe.origin.x = tvframe.origin.x-35;
      mbframe.origin.x = mbframe.origin.x-35;
      avtarframe.origin.x = avtarframe.origin.x-35;
      
      self.textView.frame = tvframe;
      self.AvatarImageView.frame = avtarframe;
      messageBackgroundView.frame = mbframe;
    }
    //end
  }
  CGRect textLabelFrame = self.textView.frame;
  textLabelFrame.origin.y = TOP_MARGIN - 17;
  self.textView.frame = textLabelFrame;
}

@end
