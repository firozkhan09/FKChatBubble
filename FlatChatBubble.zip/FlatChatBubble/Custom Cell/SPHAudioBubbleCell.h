//
//  SPHAudioBubbleCell.h
//  tawk@Eaze
//
//  Created by Santosh Narawade on 26/12/15.
//  Copyright (c) 2015 Santosh Narawade. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol AudioCellDelegate;

@interface SPHAudioBubbleCell : UITableViewCell{
    
    UIImageView *messageBackgroundView;
    UIView *containerView;
}

@property (nonatomic, retain) UILabel                 *timestampLabel;
@property (nonatomic, strong) UIImageView             *AvatarImageView;
@property (nonatomic, retain) UIImageView             *statusImageView;
@property (nonatomic, retain) UIImage                 *statusImage;
@property (nonatomic, strong) UISlider                *musicSlider;
@property (nonatomic, strong) UIButton                *actionButton;
@property (nonatomic, strong) UIActivityIndicatorView *indicator;//change
@property (nonatomic) BOOL isDownloaded, isGroup, isRecived, isProgressing;

@property (nonatomic, assign) id <AudioCellDelegate> CustomDelegate;

- (void)showMenu;

@end


#pragma mark - delegate method for MApCell

@protocol AudioCellDelegate
@required

-(void)downloadAudio:(UIButton *)sender;
-(void)uploadAudio:(UIButton *)sender;
-(void)playAudio:(UIButton *)sender;

-(void)audioCellDidTapped:(SPHAudioBubbleCell *)audioCell AndGesture:(UIGestureRecognizer*)tapGR;
-(void)audioCellDidPanned:(SPHAudioBubbleCell *)audioCell AndGesture:(UIGestureRecognizer*)panGR;
-(void)audioCellDidSelected:(SPHAudioBubbleCell *)audioCell AndGesture:(UIGestureRecognizer*)panGR;


-(void)cellForwardPressed;
-(void)cellDeletePressed;
-(void)popupAvatarImageView:(SPHAudioBubbleCell *)audioCell;

@end
