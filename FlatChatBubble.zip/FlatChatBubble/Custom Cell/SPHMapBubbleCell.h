//
//  SPHMapBubbleCell.h
//  tawk@Eaze
//
//  Created by Santosh Narawade on 21/10/15.
//  Copyright (c) 2015 Santosh Narawade. All rights reserved.
//


#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>
#import <CoreLocation/CoreLocation.h>

@protocol MapCellDelegate;

@interface SPHMapBubbleCell : UITableViewCell<MKMapViewDelegate,CLLocationManagerDelegate>{
    
    UIImageView *messageBackgroundView;
    UIView *containerView;
}

@property(nonatomic, retain) UILabel        *timestampLabel;
@property (nonatomic,strong) NSString       *bubbletype;
@property (nonatomic,strong) UIImageView    *AvatarImageView;
@property(nonatomic, retain) UIImageView    *statusImageView;
@property(nonatomic, retain) UIImage        *statusImage;
@property (nonatomic,strong) MKMapView      *shareMapView;
@property (nonatomic) BOOL isGroup;

@property (nonatomic, assign) id <MapCellDelegate> CustomDelegate;
- (void)showMenu;

@end


#pragma mark - delegate method for MApCell

@protocol MapCellDelegate
@required

-(void)mapCellDidTapped:(SPHMapBubbleCell *)mapCell AndGesture:(UIGestureRecognizer*)tapGR;
-(void)mapCellDidPanned:(SPHMapBubbleCell *)mapCell AndGesture:(UIGestureRecognizer*)panGR;

-(void)cellForwardPressed;
-(void)cellDeletePressed;

-(void)mapDidSelected:(SPHMapBubbleCell *)mapCell AndGesture:(UIGestureRecognizer*)tapGR;
-(void)popupAvatarImageView:(SPHMapBubbleCell *)mapCell;

@end






