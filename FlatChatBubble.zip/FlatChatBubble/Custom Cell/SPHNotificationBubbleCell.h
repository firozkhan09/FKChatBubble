//
//  SPHNotificationBubbleCell.h
//  tawk@Eaze
//
//  Created by Santosh Narawade on 13/01/16.
//  Copyright (c) 2016 Santosh Narawade. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SPHNotificationBubbleCell : UITableViewCell
{
    UIView *notificationContainerView;
}

@property(nonatomic, retain) UILabel *timestampLabel;


@end
