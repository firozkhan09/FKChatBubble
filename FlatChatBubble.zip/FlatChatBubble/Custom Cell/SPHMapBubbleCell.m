//
//  SPHMapBubbleCell.m
//  tawk@Eaze
//
//  Created by Santosh Narawade on 21/10/15.
//  Copyright (c) 2015 Santosh Narawade. All rights reserved.
//

#import "SPHMapBubbleCell.h"
#import "Constantvalues.h"

@implementation SPHMapBubbleCell

@synthesize timestampLabel = _timestampLabel;
@synthesize shareMapView = _shareMapView;


- (void)awakeFromNib {
  // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
  [super setSelected:selected animated:animated];
  
  // Configure the view for the selected state
}

#pragma mark - user's implimentation

/*
******************================================================***********************
******************************| INITIALIZE OF  CELL |************************************
******************================================================***********************
*/

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
  self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
  if (self) {
    self.backgroundColor = [UIColor clearColor];
    if ([[UIDevice currentDevice].systemVersion floatValue] < 7.0f) {
      self.textLabel.backgroundColor = [UIColor whiteColor];
    }
    self.textLabel.font = [UIFont systemFontOfSize:14.0f];
    self.textLabel.lineBreakMode = NSLineBreakByWordWrapping;
    self.textLabel.numberOfLines = 0;
    self.textLabel.textAlignment = NSTextAlignmentLeft;
    self.textLabel.textColor = [UIColor clearColor];
    
    messageBackgroundView = [[UIImageView alloc] initWithFrame:self.textLabel.frame];
    messageBackgroundView.layer.cornerRadius = 15.0f;
    messageBackgroundView.layer.shadowOffset = CGSizeMake(2, 0);
    messageBackgroundView.layer.shadowColor = [[UIColor blackColor] CGColor];
    messageBackgroundView.layer.shadowRadius = 5;
    messageBackgroundView.layer.shadowOpacity = .5;
    [self.contentView addSubview:messageBackgroundView];
    
    _shareMapView = [[MKMapView alloc] initWithFrame:CGRectMake(0.5,0.5,1,1)];
    _shareMapView.scrollEnabled = NO;
    [messageBackgroundView addSubview:_shareMapView];
    
    //Time and Status View
    containerView = [[UIView alloc]initWithFrame:CGRectMake(5, messageBackgroundView.frame.size.height - 23, messageBackgroundView.frame.size.width - 30, 18)];
    containerView.backgroundColor = [UIColor colorWithRed:0.0f/255.0f green:0.0f/255.0f blue:0.0f/255.0f alpha:0.15f];
    containerView.layer.cornerRadius = 5.0f;
    [messageBackgroundView insertSubview:containerView aboveSubview:self.shareMapView];
    
    _timestampLabel = [[UILabel alloc] init];
    _timestampLabel.autoresizingMask = UIViewAutoresizingFlexibleWidth;
    _timestampLabel.textAlignment = NSTextAlignmentRight;
    _timestampLabel.backgroundColor = [UIColor clearColor];
    _timestampLabel.font = [UIFont systemFontOfSize:12.0f];
    _timestampLabel.textColor = [UIColor darkGrayColor];
    [containerView addSubview:_timestampLabel];
    
    _statusImageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"seen_status"]];
    [containerView addSubview:_statusImageView];
    //end
    
    self.AvatarImageView = [[UIImageView alloc] initWithFrame:CGRectMake(5,10+TOP_MARGIN, 50, 50)];
    self.AvatarImageView.contentMode = UIViewContentModeScaleAspectFill; 
    [self.contentView addSubview:self.AvatarImageView];
    
    CALayer * l = [self.AvatarImageView layer];
    [l setMasksToBounds:YES];
    [l setCornerRadius:self.AvatarImageView.frame.size.width/2.0];
    
    CALayer * l2 = [_shareMapView layer];
    [l2 setMasksToBounds:YES];
    [l2 setCornerRadius:10];
    
    UITapGestureRecognizer *ttp = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapToPopupRecognized:)];
    [ttp setNumberOfTapsRequired:1];
    ttp.delegate = self;
    [_AvatarImageView addGestureRecognizer:ttp];
    
    UITapGestureRecognizer *tgr = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(singleTapRecognized:)];
    [tgr setNumberOfTapsRequired:1];
    tgr.delegate = self;
    [self addGestureRecognizer:tgr];
    
    UILongPressGestureRecognizer *lpgr
    = [[UILongPressGestureRecognizer alloc]
       initWithTarget:self action:@selector(tapRecognized:)];
    lpgr.minimumPressDuration = .4; //seconds
    lpgr.delegate = self;
    [self addGestureRecognizer:lpgr];
    
    UISwipeGestureRecognizer *sgr
    = [[UISwipeGestureRecognizer alloc]
       initWithTarget:self action:@selector(swipRecognized:)];
    sgr.direction = UISwipeGestureRecognizerDirectionLeft;
    sgr.delegate = self;
    [messageBackgroundView addGestureRecognizer:sgr];
  }
  return self;
}

/*
**********************=============================================**********************
*****************************|_DELEGATE_FUNCTIONS_OF_CELL_|******************************
**********************=============================================**********************
*/

-(void)tapRecognized:(UITapGestureRecognizer *)tapGR
{
  [self.CustomDelegate mapCellDidTapped:self AndGesture:tapGR];
}

-(void)swipRecognized:(UITapGestureRecognizer *)swipGR
{
  if(_isGroup)[self.CustomDelegate mapCellDidPanned:self AndGesture:swipGR];
}

-(void)singleTapRecognized:(UITapGestureRecognizer *)tapGR
{
  [self.CustomDelegate mapDidSelected:self AndGesture:tapGR];
}

-(void)tapToPopupRecognized:(UITapGestureRecognizer *)tapGR
{
  [self.CustomDelegate popupAvatarImageView:self];
}

- (BOOL)canBecomeFirstResponder {
  return YES;
}

- (BOOL)canPerformAction:(SEL)action withSender:(id)sender
{
  if (action==@selector(forward:) || action==@selector(delete:) || action==@selector(info:)) {
    return YES;
  }
  return NO;
}

- (IBAction)forward:(id)sender
{
  [self.CustomDelegate cellForwardPressed];
  self.selectionStyle = UITableViewCellSelectionStyleDefault;
  [self.CustomDelegate mapDidSelected:self AndGesture:nil];
}

- (IBAction)info:(id)sender
{
  [self.CustomDelegate mapCellDidPanned:self AndGesture:nil];
}

- (IBAction)delete:(id)sender
{
  [self.CustomDelegate cellDeletePressed];
  self.selectionStyle = UITableViewCellSelectionStyleDefault;
  [self.CustomDelegate mapDidSelected:self AndGesture:nil];
}

- (void)showMenu
{
  [[UIMenuController sharedMenuController] setMenuVisible:NO animated:YES];
  [self becomeFirstResponder];
  UIMenuItem *menuItem = [[UIMenuItem alloc] initWithTitle:@"Share" action:@selector(forward:)];
  UIMenuItem *menuItemInfo = [[UIMenuItem alloc] initWithTitle:@"Info" action:@selector(info:)];
  
  [[UIMenuController sharedMenuController] setMenuItems:[NSArray arrayWithObjects:menuItem,
                                                         (_isGroup && ![self.bubbletype isEqualToString:@"LEFT"])?menuItemInfo:nil,nil]];
  [[UIMenuController sharedMenuController] update];
  
  CGRect textFrame=self.shareMapView.frame;
  textFrame.origin.x=self.shareMapView.center.x;
  textFrame.origin.y=self.shareMapView.center.y;
  
  [[UIMenuController sharedMenuController] setTargetRect:textFrame inView:self];
  [[UIMenuController sharedMenuController] setMenuVisible:YES animated:YES];
  
}

/*
**********************=============================================**********************
*************************************| LAYOUT OF  CELL |*********************************
**********************=============================================**********************
*/

- (void)layoutSubviews
{
  [super layoutSubviews];
  
  if ([self.bubbletype isEqualToString:@"LEFT"])
  {
    messageBackgroundView.frame = CGRectMake(60,TOP_MARGIN-12, 150,150);
    self.AvatarImageView.frame=CGRectMake(5, 0, 50, 50);
    [_AvatarImageView setUserInteractionEnabled:YES];
    [messageBackgroundView setUserInteractionEnabled:NO];
    containerView.frame = CGRectMake(0, messageBackgroundView.frame.size.height - 26, messageBackgroundView.frame.size.width, 25);
    _timestampLabel.frame = CGRectMake(-60, 5, containerView.frame.size.width, 18);
    _statusImageView.image = nil;
    
  }else
  {
    messageBackgroundView.frame = CGRectMake( self.frame.size.width-210,TOP_MARGIN-12,150,150);
    self.AvatarImageView.frame=CGRectMake( self.frame.size.width-55, 0, 50, 50);
    [_AvatarImageView setUserInteractionEnabled:NO];
    [messageBackgroundView setUserInteractionEnabled:YES];
    containerView.frame = CGRectMake(0, messageBackgroundView.frame.size.height - 26, messageBackgroundView.frame.size.width, 25);
    _timestampLabel.frame = (_isGroup)?
                            CGRectMake(-60, 5, containerView.frame.size.width, 18):
                            CGRectMake(-38, 5, containerView.frame.size.width-32, 18);
    _statusImageView.frame = CGRectMake(_timestampLabel.frame.size.width-37, 5, 36, 18);
    _statusImageView.image = (_isGroup)?nil:_statusImage;
    
    //change layout on editing
    if (self.selectionStyle != UITableViewCellSelectionStyleNone) {
      CGRect mbframe = messageBackgroundView.frame;
      CGRect avtarframe = self.AvatarImageView.frame;
      mbframe.origin.x = mbframe.origin.x-35;
      avtarframe.origin.x = avtarframe.origin.x-35;
      
      self.AvatarImageView.frame = avtarframe;
      messageBackgroundView.frame = mbframe;
    }
    //end
  }
  _shareMapView.frame=CGRectMake(0.5,0.5, 149,  149);
}

@end






