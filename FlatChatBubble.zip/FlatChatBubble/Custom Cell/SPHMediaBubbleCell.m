//
//  SPHMediaBubbleCell.m
//  NewChatBubble
//
//  Created by Siba Prasad Hota  on 1/3/15.
//  Copyright (c) 2015 Wemakeappz. All rights reserved.
//

#import "SPHMediaBubbleCell.h"
#import "Constantvalues.h"

@implementation SPHMediaBubbleCell

@synthesize timestampLabel = _timestampLabel;
@synthesize messageImageView = _messageImageView;
@synthesize downloadImageButton = _downloadImageButton;
@synthesize downloadProgressView = _downloadProgressView;

/* 
******************================================================**********************
*****************************| INITIALIZE OF  CELL |************************************
******************================================================**********************
*/

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
  self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
  if (self) {
    self.backgroundColor = [UIColor clearColor];
    if ([[UIDevice currentDevice].systemVersion floatValue] < 7.0f) {
      self.textLabel.backgroundColor = [UIColor whiteColor];
    }
    self.textLabel.font = [UIFont systemFontOfSize:14.0f];
    self.textLabel.lineBreakMode = NSLineBreakByWordWrapping;
    self.textLabel.numberOfLines = 0;
    self.textLabel.textAlignment = NSTextAlignmentLeft;
    self.textLabel.textColor = [UIColor clearColor];
    
    messageBackgroundView = [[UIImageView alloc] initWithFrame:self.textLabel.frame];
    messageBackgroundView.layer.cornerRadius = 15.0f;
    messageBackgroundView.layer.shadowOffset = CGSizeMake(2, 0);
    messageBackgroundView.layer.shadowColor = [[UIColor blackColor] CGColor];
    messageBackgroundView.layer.shadowRadius = 5;
    messageBackgroundView.layer.shadowOpacity = .5;
    [self.contentView addSubview:messageBackgroundView];
    
    
    _messageImageView = [[UIImageView alloc] initWithFrame:CGRectMake(0.5,0.5,1,1)];
    _messageImageView.contentMode = UIViewContentModeScaleAspectFill;
    [messageBackgroundView addSubview:_messageImageView];
    
    //Time and Status View
    containerView = [[UIView alloc]initWithFrame:CGRectMake(5, messageBackgroundView.frame.size.height - 23, messageBackgroundView.frame.size.width - 30, 18)];
    containerView.backgroundColor = [UIColor colorWithRed:1.0f green:1.0f blue:1.0f alpha:0.15f];
    [messageBackgroundView insertSubview:containerView aboveSubview:self.textLabel];
    
    _timestampLabel = [[UILabel alloc] init];
    _timestampLabel.autoresizingMask = UIViewAutoresizingFlexibleWidth;
    _timestampLabel.textAlignment = NSTextAlignmentRight;
    _timestampLabel.backgroundColor = [UIColor clearColor];
    _timestampLabel.font = [UIFont systemFontOfSize:12.0f];
    _timestampLabel.textColor = [UIColor blackColor];
    [containerView addSubview:_timestampLabel];
    
    _statusImageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"seen_status"]];
    [containerView addSubview:_statusImageView];
    //end
    
    _downloadImageButton   = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    [self.contentView addSubview:_downloadImageButton];
    
    //change
    //indicator create
    _indicator = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
    _indicator.color = [UIColor colorWithRed:42.0f/255.0f green:125.0f/255.0f blue:215.0f/255.0f alpha:1.0f];
    [self.contentView addSubview:_indicator];
    _indicator.hidden = YES;
    //end
#warning progress view
    _downloadProgressView = [[UIProgressView alloc] initWithProgressViewStyle:UIProgressViewStyleDefault];
    _downloadProgressView.backgroundColor = [UIColor redColor];
    _downloadProgressView.progress = 0.0;
    [_downloadProgressView setTransform:CGAffineTransformMakeScale(1.0,3.0)];
    [_downloadProgressView setProgressTintColor:[UIColor greenColor]];
    [_downloadProgressView setTrackTintColor:[UIColor blackColor]];
    [_downloadProgressView setProgressViewStyle:UIProgressViewStyleDefault];
    [self.messageImageView addSubview:_downloadProgressView];
    
    self.AvatarImageView = [[UIImageView alloc] initWithFrame:
                            CGRectMake(5, 10+TOP_MARGIN, 50, 50)];
    self.AvatarImageView.contentMode = UIViewContentModeScaleAspectFill; 
    [self.contentView addSubview:self.AvatarImageView];
    
    CALayer * l = [self.AvatarImageView layer];
    [l setMasksToBounds:YES];
    [l setCornerRadius:self.AvatarImageView.frame.size.width/2.0];
    
    CALayer * l2 = [_messageImageView layer];
    [l2 setMasksToBounds:YES];
    [l2 setCornerRadius:10];
    
    UITapGestureRecognizer *ttp = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapToPopupRecognized:)];
    [ttp setNumberOfTapsRequired:1];
    ttp.delegate = self;
    [_AvatarImageView addGestureRecognizer:ttp];
    
    UITapGestureRecognizer *tgr = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(singleTapRecognized:)];
    [tgr setNumberOfTapsRequired:1];
    tgr.delegate = self;
    [messageBackgroundView setUserInteractionEnabled:YES];
    [messageBackgroundView addGestureRecognizer:tgr];
    
    UILongPressGestureRecognizer *lpgr
    = [[UILongPressGestureRecognizer alloc]
       initWithTarget:self action:@selector(tapRecognized:)];
    lpgr.minimumPressDuration = .4; //seconds
    lpgr.delegate = self;
    [self addGestureRecognizer:lpgr];
    
    UISwipeGestureRecognizer *sgr
    = [[UISwipeGestureRecognizer alloc]
       initWithTarget:self action:@selector(swipRecognized:)];
    sgr.direction = UISwipeGestureRecognizerDirectionLeft;
    sgr.delegate = self;
    [messageBackgroundView addGestureRecognizer:sgr];
  }
  return self;
}


/*
**********************=============================================**********************
*****************************|_DELEGATE_FUNCTIONS_OF_CELL_|******************************
**********************=============================================**********************
*/

-(void)downloadImageButtonClicked:(UIButton *)sender
{
  if (![[NSUserDefaults standardUserDefaults]boolForKey:@"isDownloading"]) {
    (_isDownloaded)?[self.CustomDelegate playVideo:sender]:
    (_isRecived)?   [self.CustomDelegate downloadMedia:sender]:
    [self.CustomDelegate uploadMedia:sender];
  }
  
}

-(void)tapRecognized:(UITapGestureRecognizer *)tapGR
{
    [self.CustomDelegate mediaCellDidTapped:self AndGesture:tapGR];
}

-(void)swipRecognized:(UITapGestureRecognizer *)swipGR
{
  if (_isDownloaded && _isGroup && !_isRecived)
    [self.CustomDelegate mediaCellDidPanned:self AndGesture:swipGR];
}

-(void)singleTapRecognized:(UITapGestureRecognizer *)tapGR
{
  if (_isDownloaded || self.selectionStyle != UITableViewCellSelectionStyleNone)
    [self.CustomDelegate imageDidSelected:self AndGesture:tapGR];
}

-(void)tapToPopupRecognized:(UITapGestureRecognizer *)tapGR
{
  [self.CustomDelegate popupAvatarImageView:self];
}

- (BOOL)canBecomeFirstResponder {
  return YES;
}

- (BOOL)canPerformAction:(SEL)action withSender:(id)sender
{
  if (action==@selector(forward:) || action==@selector(delete:) || action==@selector(info:)) {
    return YES;
  }
  return NO;
}

- (IBAction)forward:(id)sender
{
  [self.CustomDelegate cellForwardPressed];
  self.selectionStyle = UITableViewCellSelectionStyleDefault;
  [self.CustomDelegate imageDidSelected:self AndGesture:nil];
}

- (IBAction)info:(id)sender
{
  [self.CustomDelegate mediaCellDidPanned:self AndGesture:nil];
}

- (IBAction)delete:(id)sender
{
  [self.CustomDelegate cellDeletePressed];
  self.selectionStyle = UITableViewCellSelectionStyleDefault;
  [self.CustomDelegate imageDidSelected:self AndGesture:nil];
}

- (void)showMenu
{
  [[UIMenuController sharedMenuController] setMenuVisible:NO animated:YES];
  [self becomeFirstResponder];
  UIMenuItem *menuItem = [[UIMenuItem alloc] initWithTitle:@"Share" action:@selector(forward:)];
  UIMenuItem *menuItemInfo = [[UIMenuItem alloc] initWithTitle:@"Info" action:@selector(info:)];
  [[UIMenuController sharedMenuController] setMenuItems:[NSArray arrayWithObjects:menuItem,
                                                         (_isDownloaded && _isGroup && !_isRecived)?menuItemInfo:nil,nil]];
  [[UIMenuController sharedMenuController] update];
  
  CGRect textFrame=self.messageImageView.frame;
  textFrame.origin.x=self.messageImageView.center.x;
  textFrame.origin.y=self.messageImageView.center.y;
  
  [[UIMenuController sharedMenuController] setTargetRect:textFrame inView:self];
  [[UIMenuController sharedMenuController] setMenuVisible:YES animated:YES];
  
}

/*
**********************=============================================**********************
*************************************| LAYOUT OF  CELL |*********************************
**********************=============================================**********************
 */

- (void)layoutSubviews
{
  [super layoutSubviews];
  _messageImageView.frame=CGRectMake(0.5,0.5, 149,  149);
  int dist = ([_dataType isEqualToString:@"contact"])?6:26;
  if (_isRecived)
  {
    messageBackgroundView.frame = CGRectMake(60, TOP_MARGIN-12, 150,150);
    self.AvatarImageView.frame=CGRectMake(5, 0, 50, 50);
    [_AvatarImageView setUserInteractionEnabled:YES];
    containerView.frame = CGRectMake(0, messageBackgroundView.frame.size.height - dist, messageBackgroundView.frame.size.width, 25);
    _downloadImageButton.frame = CGRectMake( 115, 63, 40, 40);
    _timestampLabel.frame = CGRectMake(-60, 5, containerView.frame.size.width, 18);
    _statusImageView.image = nil;
    containerView.hidden = NO;
    
    [_downloadImageButton setBackgroundImage:
     (_isDownloaded)?[UIImage imageNamed:@"play"]:[UIImage imageNamed:@"download"]
                                    forState:UIControlStateNormal];
    
    _downloadProgressView.frame = CGRectMake(0, self.messageImageView.frame.size.height - 10, self.messageImageView.frame.size.width, 2);
    _downloadProgressView.hidden = (_isProgressing)?NO:YES;
  }
  else{
    
    messageBackgroundView.frame = CGRectMake( self.frame.size.width-210,TOP_MARGIN-12,150,150);
    self.AvatarImageView.frame=CGRectMake( self.frame.size.width-55, 0, 50, 50);
    [_AvatarImageView setUserInteractionEnabled:NO];
    _downloadImageButton.frame = CGRectMake( messageBackgroundView.frame.origin.x+60, 63, 40, 40);
    containerView.frame = CGRectMake(0, messageBackgroundView.frame.size.height - dist, messageBackgroundView.frame.size.width, 25);
    _timestampLabel.frame = (_isGroup)?
                            CGRectMake(-60, 5, containerView.frame.size.width, 18):
                            CGRectMake(-38, 5, containerView.frame.size.width-32, 18);
    _statusImageView.frame = CGRectMake(_timestampLabel.frame.size.width-37, 5, 36, 18);
    _statusImageView.image = (_isGroup)?nil:_statusImage;
    containerView.hidden = (_isDownloaded)?NO:YES;
    
    [_downloadImageButton setBackgroundImage:
     (_isDownloaded)?[UIImage imageNamed:@"play"]:[UIImage imageNamed:@"upload"]
                                    forState:UIControlStateNormal];
    //change layout on editing
    if (self.selectionStyle != UITableViewCellSelectionStyleNone) {
      CGRect btnframe = self.downloadImageButton.frame;
      CGRect mbframe = messageBackgroundView.frame;
      CGRect avtarframe = self.AvatarImageView.frame;
      btnframe.origin.x = btnframe.origin.x-35;
      mbframe.origin.x = mbframe.origin.x-35;
      avtarframe.origin.x = avtarframe.origin.x-35;
      
      self.downloadImageButton.frame = btnframe;
      self.AvatarImageView.frame = avtarframe;
      messageBackgroundView.frame = mbframe;
    }
    //end
  }
  containerView.layer.cornerRadius = 5.0f;
  _indicator.center = self.downloadImageButton.center;
  _indicator.hidden = (_isProgressing)?NO:YES;
  (_isProgressing)?[_indicator startAnimating]:[_indicator stopAnimating];
  [_downloadImageButton addTarget: self action:@selector(downloadImageButtonClicked:) forControlEvents:UIControlEventTouchUpInside];
  _downloadImageButton.hidden=([self.dataType isEqualToString:@"image"])?
                              (_isDownloaded)?
                              YES:_isProgressing:
                              ([self.dataType isEqualToString:@"video"])?
                              _isProgressing:YES;
}

@end
