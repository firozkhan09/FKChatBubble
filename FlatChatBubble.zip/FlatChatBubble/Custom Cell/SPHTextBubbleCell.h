//
//  SPHLeftBubbleCell.h
//  NewChatBubble
//
//  Created by Siba Prasad Hota  on 1/3/15.
//  Copyright (c) 2015 Wemakeappz. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol TextCellDelegate;

@interface SPHTextBubbleCell : UITableViewCell <UITextViewDelegate>
{
    UIImageView *messageBackgroundView;
    UIView *containerView;
}

@property(nonatomic, retain) UITextView     *textView;
@property(nonatomic, retain) UILabel        *timestampLabel;
@property (nonatomic,strong) NSString       *bubbletype;
@property (nonatomic,strong) UIImageView    *AvatarImageView;
@property(nonatomic, retain) UIImageView    *statusImageView;
@property(nonatomic, retain) UIImage        *statusImage;
@property (nonatomic) BOOL isGroup;

@property (nonatomic, assign) id <TextCellDelegate> CustomDelegate;

- (void)showMenu;


@end


@protocol TextCellDelegate
@required

-(void)textCellDidTapped:(SPHTextBubbleCell *)tesxtCell AndGesture:(UIGestureRecognizer*)tapGR;
-(void)textCellDidPanned:(SPHTextBubbleCell *)tesxtCell AndGesture:(UIGestureRecognizer*)panGR;
-(void)textCellDidSelected:(SPHTextBubbleCell *)tesxtCell AndGesture:(UIGestureRecognizer*)panGR;

-(void)cellCopyPressed:(SPHTextBubbleCell *)tesxtCell;
-(void)cellForwardPressed;
-(void)cellDeletePressed;
-(void)popupAvatarImageView:(SPHTextBubbleCell *)tesxtCell;

@end

